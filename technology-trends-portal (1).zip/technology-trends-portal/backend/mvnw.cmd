@REM ----------------------------------------------------------------------------
@REM Maven Wrapper startup batch script
@REM ----------------------------------------------------------------------------
@setlocal
@set WRAPPER_URL=https://repo.maven.apache.org/maven2/org/apache/maven/wrapper/maven-wrapper/3.2.0/maven-wrapper-3.2.0.jar
@set WRAPPER_JAR=".mvn\wrapper\maven-wrapper.jar"

@if exist %WRAPPER_JAR% goto execute

@echo Downloading Maven Wrapper...
@powershell -Command "(New-Object Net.WebClient).DownloadFile('%WRAPPER_URL%', '%WRAPPER_JAR%')"

:execute
@java -jar %WRAPPER_JAR% %*
