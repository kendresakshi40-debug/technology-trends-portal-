package com.project.trends;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrendsPortalApplication {
    public static void main(String[] args) {
        SpringApplication.run(TrendsPortalApplication.class, args);
    }
}
