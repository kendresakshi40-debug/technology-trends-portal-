package com.project.trends.model;

public enum AuthProvider {
    LOCAL,
    GOOGLE,
    FACEBOOK
}
