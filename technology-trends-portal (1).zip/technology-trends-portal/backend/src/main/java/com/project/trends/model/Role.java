package com.project.trends.model;

public enum Role {
    ROLE_USER,
    ROLE_ADMIN
}
