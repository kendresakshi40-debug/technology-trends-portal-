package com.project.trends.controller;

import com.project.trends.service.TrendDataService;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api")
@CrossOrigin
public class MainController {

    private final TrendDataService trendDataService;

    public MainController(TrendDataService trendDataService) {
        this.trendDataService = trendDataService;
    }

    @GetMapping("/technologies")
    public List<String> getTech() {
        return Arrays.asList("AI", "Cloud Computing", "Cybersecurity");
    }

    @GetMapping("/dashboard/trending-technologies")
    public List<Map<String, Object>> getTrendingTechnologies() {
        return trendDataService.fetchTrendingTechnologies();
    }

    @GetMapping("/dashboard/publication-trends")
    public Map<String, Object> getPublicationTrends() {
        return trendDataService.fetchPublicationTrends();
    }

    @GetMapping("/dashboard/map-density")
    public List<Map<String, Object>> getMapDensity() {
        return trendDataService.fetchMapDensity();
    }

    @GetMapping("/dashboard/insights")
    public List<Map<String, Object>> getInsights() {
        List<Map<String, Object>> trending = trendDataService.fetchTrendingTechnologies();
        return trendDataService.generateInsights(trending);
    }

    @GetMapping("/dashboard/research-keywords")
    public List<Map<String, Object>> getResearchKeywords() {
        return trendDataService.fetchResearchKeywords();
    }
}
