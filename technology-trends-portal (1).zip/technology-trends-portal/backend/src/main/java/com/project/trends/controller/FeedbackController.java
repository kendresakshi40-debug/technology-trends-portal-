package com.project.trends.controller;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.MailException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/dashboard")
@CrossOrigin
public class FeedbackController {

    private final JavaMailSender mailSender;

    @Value("${app.feedback.to-email}")
    private String toEmail;

    public FeedbackController(JavaMailSender mailSender) {
        this.mailSender = mailSender;
    }

    @PostMapping("/feedback")
    public ResponseEntity<Map<String, String>> submitFeedback(@RequestBody Map<String, String> feedback) {
        String name = feedback.get("name");
        String email = feedback.get("email");
        String message = feedback.get("message");

        if (name == null || name.isBlank() || email == null || email.isBlank() || message == null || message.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("error", "All fields are required"));
        }

        try {
            MimeMessage mimeMessage = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true);
            helper.setTo(toEmail);
            helper.setSubject("Feedback from " + name + " - Technology Trends Portal");
            helper.setReplyTo(email);
            helper.setText(
                "<h3>New Feedback Received</h3>" +
                "<p><strong>Name:</strong> " + escapeHtml(name) + "</p>" +
                "<p><strong>Email:</strong> " + escapeHtml(email) + "</p>" +
                "<p><strong>Message:</strong></p>" +
                "<p>" + escapeHtml(message) + "</p>",
                true
            );
            mailSender.send(mimeMessage);
            return ResponseEntity.ok(Map.of("message", "Feedback sent successfully!"));
        } catch (MessagingException | MailException e) {
            return ResponseEntity.internalServerError().body(Map.of("error", "Failed to send feedback. Please try again later."));
        }
    }

    private String escapeHtml(String input) {
        return input.replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;")
                    .replace("\"", "&quot;")
                    .replace("'", "&#39;");
    }
}
