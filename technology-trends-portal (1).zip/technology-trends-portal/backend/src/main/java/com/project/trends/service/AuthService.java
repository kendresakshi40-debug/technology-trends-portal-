package com.project.trends.service;

import com.project.trends.dto.*;
import com.project.trends.model.*;
import com.project.trends.repository.UserRepository;
import com.project.trends.security.CustomUserDetails;
import com.project.trends.security.JwtTokenProvider;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.*;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final JwtTokenProvider tokenProvider;

    public AuthResponse register(RegisterRequest request) {
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new RuntimeException("Email already registered");
        }

        User user = User.builder()
                .fullName(request.getFullName())
                .email(request.getEmail())
                .password(passwordEncoder.encode(request.getPassword()))
                .role(Role.ROLE_USER)
                .provider(AuthProvider.LOCAL)
                .build();

        userRepository.save(user);

        Authentication auth = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword()));

        String token = tokenProvider.generateToken(auth, false);
        return new AuthResponse(token, user.getRole().name(), user.getFullName(), user.getEmail());
    }

    public AuthResponse login(LoginRequest request) {
        Authentication auth = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword()));

        CustomUserDetails userDetails = (CustomUserDetails) auth.getPrincipal();
        User user = userDetails.getUser();

        String token = tokenProvider.generateToken(auth, request.isRememberMe());
        return new AuthResponse(token, user.getRole().name(), user.getFullName(), user.getEmail());
    }

    public AuthResponse adminLogin(LoginRequest request) {
        Authentication auth = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword()));

        CustomUserDetails userDetails = (CustomUserDetails) auth.getPrincipal();
        User user = userDetails.getUser();

        if (user.getRole() != Role.ROLE_ADMIN) {
            throw new RuntimeException("Access denied. Admin privileges required.");
        }

        String token = tokenProvider.generateToken(auth, request.isRememberMe());
        return new AuthResponse(token, user.getRole().name(), user.getFullName(), user.getEmail());
    }

    public String forgotPassword(ForgotPasswordRequest request) {
        userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new RuntimeException("No account found with this email"));
        // In production: generate reset token and send email
        return "Password reset link has been sent to your email.";
    }
}
