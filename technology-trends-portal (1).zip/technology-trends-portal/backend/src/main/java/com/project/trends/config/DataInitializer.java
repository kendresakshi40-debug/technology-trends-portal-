package com.project.trends.config;

import com.project.trends.model.*;
import com.project.trends.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        // Create default admin if not exists
        if (!userRepository.existsByEmail("admin@trends.com")) {
            User admin = User.builder()
                    .fullName("System Admin")
                    .email("admin@trends.com")
                    .password(passwordEncoder.encode("admin123"))
                    .role(Role.ROLE_ADMIN)
                    .provider(AuthProvider.LOCAL)
                    .enabled(true)
                    .build();
            userRepository.save(admin);
        }

        // Create dummy users
        String[][] dummyUsers = {
                {"Rahul Sharma", "rahul@example.com"},
                {"Priya Patel", "priya@example.com"},
                {"Amit Kumar", "amit@example.com"}
        };
        for (String[] du : dummyUsers) {
            if (!userRepository.existsByEmail(du[1])) {
                User user = User.builder()
                        .fullName(du[0])
                        .email(du[1])
                        .password(passwordEncoder.encode("user123"))
                        .role(Role.ROLE_USER)
                        .provider(AuthProvider.LOCAL)
                        .enabled(true)
                        .build();
                userRepository.save(user);
            }
        }
    }
}
