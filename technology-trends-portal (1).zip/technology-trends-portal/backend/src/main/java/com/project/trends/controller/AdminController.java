package com.project.trends.controller;

import com.project.trends.model.Role;
import com.project.trends.model.User;
import com.project.trends.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/admin")
@CrossOrigin
@RequiredArgsConstructor
public class AdminController {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    // ==================== Stats ====================

    @GetMapping("/stats")
    public Map<String, Object> getStats() {
        List<User> users = userRepository.findAll();
        long total = users.size();
        long admins = users.stream().filter(u -> u.getRole() == Role.ROLE_ADMIN).count();
        long regularUsers = total - admins;
        long enabledCount = users.stream().filter(User::isEnabled).count();

        LocalDateTime weekAgo = LocalDateTime.now().minusDays(7);
        long newThisWeek = users.stream()
                .filter(u -> u.getCreatedAt() != null && u.getCreatedAt().isAfter(weekAgo))
                .count();

        Map<String, Object> stats = new LinkedHashMap<>();
        stats.put("totalUsers", total);
        stats.put("admins", admins);
        stats.put("regularUsers", regularUsers);
        stats.put("enabledUsers", enabledCount);
        stats.put("disabledUsers", total - enabledCount);
        stats.put("newThisWeek", newThisWeek);
        return stats;
    }

    // ==================== Users List ====================

    @GetMapping("/users")
    public List<Map<String, Object>> getUsers() {
        return userRepository.findAll().stream().map(u -> {
            Map<String, Object> map = new LinkedHashMap<>();
            map.put("id", u.getId());
            map.put("fullName", u.getFullName());
            map.put("email", u.getEmail());
            map.put("role", u.getRole().name());
            map.put("provider", u.getProvider() != null ? u.getProvider().name() : "LOCAL");
            map.put("enabled", u.isEnabled());
            map.put("createdAt", u.getCreatedAt() != null ? u.getCreatedAt().toString() : null);
            return map;
        }).collect(Collectors.toList());
    }

    // ==================== User Growth Chart ====================

    @GetMapping("/user-growth")
    public Map<String, Object> getUserGrowth() {
        List<User> users = userRepository.findAll();

        // Last 30 days
        Map<String, Long> dailyCounts = new LinkedHashMap<>();
        LocalDate today = LocalDate.now();
        for (int i = 29; i >= 0; i--) {
            LocalDate date = today.minusDays(i);
            dailyCounts.put(date.toString(), 0L);
        }

        for (User u : users) {
            if (u.getCreatedAt() != null) {
                String dateStr = u.getCreatedAt().toLocalDate().toString();
                if (dailyCounts.containsKey(dateStr)) {
                    dailyCounts.merge(dateStr, 1L, Long::sum);
                }
            }
        }

        // Cumulative
        List<String> labels = new ArrayList<>();
        List<Long> cumulative = new ArrayList<>();
        long cumTotal = users.stream()
                .filter(u -> u.getCreatedAt() != null && u.getCreatedAt().toLocalDate().isBefore(today.minusDays(29)))
                .count();

        for (var entry : dailyCounts.entrySet()) {
            labels.add(entry.getKey().substring(5)); // MM-DD
            cumTotal += entry.getValue();
            cumulative.add(cumTotal);
        }

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("labels", labels);
        result.put("data", cumulative);
        return result;
    }

    // ==================== Toggle User Status ====================

    @PutMapping("/users/{id}/toggle")
    public ResponseEntity<Map<String, Object>> toggleUser(@PathVariable Long id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found"));

        user.setEnabled(!user.isEnabled());
        userRepository.save(user);

        Map<String, Object> resp = new LinkedHashMap<>();
        resp.put("id", user.getId());
        resp.put("enabled", user.isEnabled());
        resp.put("message", user.isEnabled() ? "User enabled" : "User disabled");
        return ResponseEntity.ok(resp);
    }

    // ==================== Delete User ====================

    @DeleteMapping("/users/{id}")
    public ResponseEntity<Map<String, String>> deleteUser(@PathVariable Long id) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found"));

        if (user.getRole() == Role.ROLE_ADMIN) {
            long adminCount = userRepository.findAll().stream()
                    .filter(u -> u.getRole() == Role.ROLE_ADMIN).count();
            if (adminCount <= 1) {
                throw new RuntimeException("Cannot delete the last admin");
            }
        }

        userRepository.delete(user);
        return ResponseEntity.ok(Map.of("message", "User deleted successfully"));
    }

    // ==================== Change User Role ====================

    @PutMapping("/users/{id}/role")
    public ResponseEntity<Map<String, Object>> changeRole(@PathVariable Long id, @RequestBody Map<String, String> body) {
        User user = userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found"));

        // Prevent demoting the last admin
        if (user.getRole() == Role.ROLE_ADMIN && !"ROLE_ADMIN".equals(body.get("role"))) {
            long adminCount = userRepository.findAll().stream()
                    .filter(u -> u.getRole() == Role.ROLE_ADMIN).count();
            if (adminCount <= 1) {
                throw new RuntimeException("Cannot demote the last admin");
            }
        }

        String newRole = body.get("role");
        if ("ROLE_ADMIN".equals(newRole)) {
            user.setRole(Role.ROLE_ADMIN);
        } else {
            user.setRole(Role.ROLE_USER);
        }
        userRepository.save(user);

        Map<String, Object> resp = new LinkedHashMap<>();
        resp.put("id", user.getId());
        resp.put("role", user.getRole().name());
        resp.put("message", "Role updated to " + user.getRole().name());
        return ResponseEntity.ok(resp);
    }

    // ==================== System Info ====================

    @GetMapping("/system")
    public Map<String, Object> getSystemInfo() {
        Runtime rt = Runtime.getRuntime();
        Map<String, Object> info = new LinkedHashMap<>();
        info.put("javaVersion", System.getProperty("java.version"));
        info.put("osName", System.getProperty("os.name"));
        info.put("totalMemoryMB", rt.totalMemory() / (1024 * 1024));
        info.put("freeMemoryMB", rt.freeMemory() / (1024 * 1024));
        info.put("usedMemoryMB", (rt.totalMemory() - rt.freeMemory()) / (1024 * 1024));
        info.put("maxMemoryMB", rt.maxMemory() / (1024 * 1024));
        info.put("processors", rt.availableProcessors());
        info.put("uptime", java.lang.management.ManagementFactory.getRuntimeMXBean().getUptime() / 1000);
        return info;
    }
}
