package com.project.trends.service;

import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Supplier;

@Service
public class TrendDataService {

    private final RestTemplate restTemplate = new RestTemplate();
    private final Map<String, CacheEntry> cache = new ConcurrentHashMap<>();
    private static final long CACHE_TTL = 3_600_000; // 1 hour

    private static final String BASE = "https://api.openalex.org";
    private static final String MAIL = "mailto=trendsportal@example.com";

    // Known OpenAlex concept IDs for CS subfields (fetched individually)
    private static final String[][] TECH_CONCEPTS = {
            {"C154945302", "Artificial Intelligence", "#38bdf8"},
            {"C119857082", "Machine Learning", "#a78bfa"},
            {"C31972630", "Computer Network", "#fb923c"},
            {"C38652104", "Computer Security", "#fbbf24"},
            {"C31258907", "Computer Vision", "#34d399"},
            {"C124101348", "Data Mining", "#f472b6"},
            {"C199360897", "Database", "#818cf8"},
            {"C121332964", "Operating System", "#22d3ee"},
    };

    // Top 4 for chart
    private static final String[][] CHART_CONCEPTS = {
            {"C154945302", "Artificial Intelligence", "#38bdf8"},
            {"C119857082", "Machine Learning", "#a78bfa"},
            {"C38652104", "Computer Security", "#fb923c"},
            {"C31972630", "Computer Network", "#34d399"},
    };

    // Level-2 keywords
    private static final String[][] KEYWORD_CONCEPTS = {
            {"C108583219", "Deep Learning"},
            {"C50644808", "Artificial Neural Network"},
            {"C97137747", "Encryption"},
            {"C8880873", "Reinforcement Learning"},
            {"C204321447", "Natural Language Processing"},
            {"C195094911", "Convolutional Neural Network"},
            {"C77088390", "Cloud Computing"},
            {"C126255220", "Recurrent Neural Network"},
            {"C41512826", "Object Detection"},
            {"C33923547", "Random Forest"},
            {"C4249254", "Robot"},
            {"C23123220", "Cluster Analysis"},
    };

    private static final String[] COLORS = {
            "#38bdf8", "#a78bfa", "#fb923c", "#fbbf24",
            "#34d399", "#f472b6", "#818cf8", "#22d3ee"
    };

    private static final Map<String, String> COUNTRY_TO_REGION = new HashMap<>();
    private static final Map<String, double[]> REGION_COORDS = new HashMap<>();

    static {
        for (String c : List.of("US", "CA", "MX")) COUNTRY_TO_REGION.put(c, "North America");
        for (String c : List.of("GB", "DE", "FR", "IT", "ES", "NL", "SE", "CH", "PL", "AT", "BE",
                "DK", "FI", "NO", "IE", "PT", "CZ", "RO", "HU", "GR", "UA", "RU"))
            COUNTRY_TO_REGION.put(c, "Europe");
        for (String c : List.of("CN", "JP", "KR", "TW", "HK", "SG"))
            COUNTRY_TO_REGION.put(c, "East Asia");
        for (String c : List.of("IN", "PK", "BD", "LK", "NP"))
            COUNTRY_TO_REGION.put(c, "South Asia");
        for (String c : List.of("BR", "AR", "CL", "CO", "PE", "VE", "EC", "UY"))
            COUNTRY_TO_REGION.put(c, "South America");
        for (String c : List.of("ZA", "NG", "EG", "KE", "GH", "TN", "MA", "ET"))
            COUNTRY_TO_REGION.put(c, "Africa");
        for (String c : List.of("AU", "NZ"))
            COUNTRY_TO_REGION.put(c, "Oceania");
        for (String c : List.of("SA", "IR", "IL", "AE", "TR", "QA", "IQ", "JO", "KW"))
            COUNTRY_TO_REGION.put(c, "Middle East");

        REGION_COORDS.put("North America", new double[]{39.8, -98.5});
        REGION_COORDS.put("Europe", new double[]{50.0, 10.0});
        REGION_COORDS.put("East Asia", new double[]{35.0, 105.0});
        REGION_COORDS.put("South Asia", new double[]{20.0, 78.0});
        REGION_COORDS.put("South America", new double[]{-15.0, -55.0});
        REGION_COORDS.put("Africa", new double[]{5.0, 25.0});
        REGION_COORDS.put("Oceania", new double[]{-25.0, 135.0});
        REGION_COORDS.put("Middle East", new double[]{28.0, 45.0});
    }

    // ==================== Public API Methods ====================

    public List<Map<String, Object>> fetchTrendingTechnologies() {
        return getCached("trending", () -> {
            try {
                List<Map<String, Object>> list = new ArrayList<>();
                for (int i = 0; i < TECH_CONCEPTS.length; i++) {
                    String id = TECH_CONCEPTS[i][0];
                    String name = TECH_CONCEPTS[i][1];
                    String color = TECH_CONCEPTS[i][2];

                    JsonNode c = fetchConcept(id);
                    if (c == null) continue;

                    int worksCount = c.get("works_count").asInt();
                    JsonNode yearlyGroups = fetchYearlyGroups(id);
                    double growth = calcGrowth(yearlyGroups);

                    Map<String, Object> tech = new LinkedHashMap<>();
                    tech.put("name", name);
                    tech.put("growth", round1(growth));
                    tech.put("publications", worksCount);
                    tech.put("color", color);
                    list.add(tech);
                }
                if (list.isEmpty()) return defaultTrending();
                list.sort((a, b) -> ((Number) b.get("publications")).intValue() - ((Number) a.get("publications")).intValue());
                return list;
            } catch (Exception e) {
                return defaultTrending();
            }
        });
    }

    public Map<String, Object> fetchPublicationTrends() {
        return getCached("pubtrends", () -> {
            try {
                List<String> labels = null;
                List<Map<String, Object>> datasets = new ArrayList<>();

                int currentYear = java.time.Year.now().getValue();
                for (String[] def : CHART_CONCEPTS) {
                    JsonNode groups = fetchYearlyGroups(def[0]);
                    if (groups == null || groups.isEmpty()) continue;

                    // Collect year->count, skip current incomplete year
                    java.util.TreeMap<Integer, Integer> yearMap = new java.util.TreeMap<>();
                    for (JsonNode g : groups) {
                        int year = Integer.parseInt(g.get("key").asText());
                        if (year >= currentYear) continue;
                        yearMap.put(year, (int) g.get("count").asLong());
                    }
                    if (yearMap.size() < 2) continue;

                    // Take last 8 years in ascending order
                    List<String> years = new ArrayList<>();
                    List<Integer> values = new ArrayList<>();
                    var entries = new ArrayList<>(yearMap.entrySet());
                    int start = Math.max(0, entries.size() - 8);
                    for (int j = start; j < entries.size(); j++) {
                        years.add(String.valueOf(entries.get(j).getKey()));
                        values.add(entries.get(j).getValue());
                    }
                    if (labels == null) labels = years;

                    Map<String, Object> ds = new LinkedHashMap<>();
                    ds.put("label", def[1]);
                    ds.put("data", values);
                    ds.put("color", def[2]);
                    datasets.add(ds);
                }

                if (datasets.isEmpty()) return defaultPubTrends();

                Map<String, Object> data = new LinkedHashMap<>();
                data.put("labels", labels);
                data.put("datasets", datasets);
                return data;
            } catch (Exception e) {
                return defaultPubTrends();
            }
        });
    }

    public List<Map<String, Object>> fetchMapDensity() {
        return getCached("mapdensity", () -> {
            try {
                String url = BASE + "/works?group_by=authorships.countries&filter=concept.id:C41008148&per_page=200&" + MAIL;
                JsonNode root = restTemplate.getForObject(url, JsonNode.class);
                JsonNode groups = root != null ? root.get("group_by") : null;

                if (groups == null || groups.isEmpty()) return defaultMapDensity();

                Map<String, Long> regionPapers = new LinkedHashMap<>();
                for (JsonNode g : groups) {
                    String code = g.get("key").asText();
                    long count = g.get("count").asLong();
                    String region = COUNTRY_TO_REGION.get(code);
                    if (region != null) {
                        regionPapers.merge(region, count, Long::sum);
                    }
                }

                if (regionPapers.isEmpty()) return defaultMapDensity();

                long maxPapers = regionPapers.values().stream().mapToLong(Long::longValue).max().orElse(1);

                List<Map<String, Object>> result = new ArrayList<>();
                for (var entry : regionPapers.entrySet()) {
                    double[] coords = REGION_COORDS.get(entry.getKey());
                    if (coords == null) continue;
                    int density = (int) Math.round((double) entry.getValue() / maxPapers * 100);

                    Map<String, Object> region = new LinkedHashMap<>();
                    region.put("region", entry.getKey());
                    region.put("lat", coords[0]);
                    region.put("lng", coords[1]);
                    region.put("density", density);
                    region.put("papers", entry.getValue());
                    result.add(region);
                }
                result.sort((a, b) -> ((Number) b.get("density")).intValue() - ((Number) a.get("density")).intValue());
                return result;
            } catch (Exception e) {
                return defaultMapDensity();
            }
        });
    }

    public List<Map<String, Object>> fetchResearchKeywords() {
        return getCached("keywords", () -> {
            try {
                List<Map<String, Object>> result = new ArrayList<>();
                for (String[] def : KEYWORD_CONCEPTS) {
                    JsonNode c = fetchConcept(def[0]);
                    if (c == null) continue;

                    int count = c.get("works_count").asInt();
                    JsonNode yearlyGroups = fetchYearlyGroups(def[0]);
                    double growth = calcGrowth(yearlyGroups);

                    Map<String, Object> kw = new LinkedHashMap<>();
                    kw.put("keyword", def[1]);
                    kw.put("count", count);
                    kw.put("growth", round1(growth));
                    result.add(kw);
                }
                if (result.isEmpty()) return defaultKeywords();
                result.sort((a, b) -> ((Number) b.get("count")).intValue() - ((Number) a.get("count")).intValue());
                return result;
            } catch (Exception e) {
                return defaultKeywords();
            }
        });
    }

    public List<Map<String, Object>> generateInsights(List<Map<String, Object>> trending) {
        List<Map<String, Object>> insights = new ArrayList<>();
        if (trending == null || trending.size() < 4) return defaultInsights();

        try {
            Map<String, Object> top = trending.get(0);
            insights.add(makeInsight(
                    top.get("name") + " Leads Research",
                    top.get("name") + " dominates with " + fmtNum((Number) top.get("publications"))
                            + " publications and " + top.get("growth") + "% year-over-year growth.",
                    "🤖", "up"));

            Map<String, Object> fastest = trending.stream()
                    .max(Comparator.comparingDouble(t -> ((Number) t.get("growth")).doubleValue()))
                    .orElse(trending.get(1));
            insights.add(makeInsight(
                    fastest.get("name") + " Growing Fastest",
                    fastest.get("name") + " shows the highest growth rate at " + fastest.get("growth")
                            + "%, signaling strong emerging interest.",
                    "📈", "up"));

            Map<String, Object> t3 = trending.get(2);
            insights.add(makeInsight(
                    t3.get("name") + " Expanding Steadily",
                    t3.get("name") + " continues to grow with " + fmtNum((Number) t3.get("publications"))
                            + " publications worldwide.",
                    "🔬", ((Number) t3.get("growth")).doubleValue() > 5 ? "up" : "stable"));

            long totalPubs = trending.stream().mapToLong(t -> ((Number) t.get("publications")).longValue()).sum();
            insights.add(makeInsight(
                    "Research Output Surging",
                    "Top technology domains collectively account for " + fmtNum(totalPubs)
                            + " publications, reflecting unprecedented research activity.",
                    "🌍", "up"));
        } catch (Exception e) {
            return defaultInsights();
        }
        return insights;
    }

    // ==================== Helpers ====================

    private JsonNode fetchConcept(String conceptId) {
        try {
            String url = BASE + "/concepts/" + conceptId + "?" + MAIL;
            return restTemplate.getForObject(url, JsonNode.class);
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Fetch yearly publication groups for a concept from the works API.
     * Returns the group_by array sorted by year descending, or null on failure.
     */
    private JsonNode fetchYearlyGroups(String conceptId) {
        try {
            String url = BASE + "/works?filter=concepts.id:" + conceptId
                    + "&group_by=publication_year&per_page=10&" + MAIL;
            JsonNode root = restTemplate.getForObject(url, JsonNode.class);
            return root != null ? root.get("group_by") : null;
        } catch (Exception e) {
            return null;
        }
    }

    private double calcGrowth(JsonNode yearlyGroups) {
        if (yearlyGroups == null || yearlyGroups.size() < 2) return 0;
        int currentYear = java.time.Year.now().getValue();

        // Collect counts keyed by year, skipping current (incomplete) year
        java.util.TreeMap<Integer, Long> yearCounts = new java.util.TreeMap<>(Comparator.reverseOrder());
        for (JsonNode entry : yearlyGroups) {
            int year = Integer.parseInt(entry.get("key").asText());
            if (year >= currentYear) continue;
            long count = entry.get("count").asLong();
            yearCounts.put(year, count);
        }

        // Need at least two complete years
        if (yearCounts.size() < 2) return 0;
        var it = yearCounts.values().iterator();
        long recent = it.next();
        long previous = it.next();
        if (previous == 0) return 0;
        return ((double) (recent - previous) / previous) * 100;
    }

    private double round1(double v) {
        return Math.round(v * 10.0) / 10.0;
    }

    private String fmtNum(Number n) {
        long v = n.longValue();
        if (v >= 1_000_000) return String.format("%.1fM", v / 1_000_000.0);
        if (v >= 1_000) return String.format("%.1fK", v / 1_000.0);
        return String.valueOf(v);
    }

    private Map<String, Object> makeInsight(String title, String desc, String icon, String trend) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("title", title);
        m.put("description", desc);
        m.put("icon", icon);
        m.put("trend", trend);
        return m;
    }

    @SuppressWarnings("unchecked")
    private <T> T getCached(String key, Supplier<T> supplier) {
        CacheEntry entry = cache.get(key);
        if (entry != null && System.currentTimeMillis() - entry.timestamp < CACHE_TTL) {
            return (T) entry.data;
        }
        T data = supplier.get();
        cache.put(key, new CacheEntry(data, System.currentTimeMillis()));
        return data;
    }

    // ==================== Fallback Defaults ====================

    private List<Map<String, Object>> defaultTrending() {
        List<Map<String, Object>> list = new ArrayList<>();
        list.add(Map.of("name", "Artificial Intelligence", "growth", 32.5, "publications", 48200, "color", "#38bdf8"));
        list.add(Map.of("name", "Computer Networks", "growth", 18.7, "publications", 22400, "color", "#a78bfa"));
        list.add(Map.of("name", "Computer Security", "growth", 21.9, "publications", 38900, "color", "#fb923c"));
        list.add(Map.of("name", "Machine Learning", "growth", 28.1, "publications", 35600, "color", "#fbbf24"));
        list.add(Map.of("name", "Data Mining", "growth", 15.8, "publications", 29300, "color", "#34d399"));
        list.add(Map.of("name", "Computer Vision", "growth", 24.3, "publications", 15600, "color", "#f472b6"));
        list.add(Map.of("name", "Database", "growth", 12.4, "publications", 11200, "color", "#818cf8"));
        list.add(Map.of("name", "Operating System", "growth", 8.6, "publications", 8700, "color", "#22d3ee"));
        return list;
    }

    private Map<String, Object> defaultPubTrends() {
        Map<String, Object> data = new LinkedHashMap<>();
        data.put("labels", List.of("2019", "2020", "2021", "2022", "2023", "2024", "2025", "2026"));
        data.put("datasets", List.of(
                Map.of("label", "Artificial Intelligence", "data", List.of(12000, 18500, 24000, 31000, 38000, 42500, 46000, 48200), "color", "#38bdf8"),
                Map.of("label", "Computer Networks", "data", List.of(8500, 14200, 19800, 22000, 23100, 22800, 22500, 22400), "color", "#a78bfa"),
                Map.of("label", "Computer Security", "data", List.of(18000, 22000, 26500, 30000, 33500, 36000, 37800, 38900), "color", "#fb923c"),
                Map.of("label", "Machine Learning", "data", List.of(5000, 8200, 12500, 18000, 24000, 29000, 33000, 35600), "color", "#34d399")
        ));
        return data;
    }

    private List<Map<String, Object>> defaultMapDensity() {
        List<Map<String, Object>> list = new ArrayList<>();
        list.add(Map.of("region", "North America", "lat", 39.8, "lng", -98.5, "density", 92, "papers", 128400));
        list.add(Map.of("region", "Europe", "lat", 50.0, "lng", 10.0, "density", 87, "papers", 115200));
        list.add(Map.of("region", "East Asia", "lat", 35.0, "lng", 105.0, "density", 94, "papers", 142800));
        list.add(Map.of("region", "South Asia", "lat", 20.0, "lng", 78.0, "density", 68, "papers", 52300));
        list.add(Map.of("region", "South America", "lat", -15.0, "lng", -55.0, "density", 38, "papers", 18900));
        list.add(Map.of("region", "Africa", "lat", 5.0, "lng", 25.0, "density", 22, "papers", 9200));
        list.add(Map.of("region", "Oceania", "lat", -25.0, "lng", 135.0, "density", 45, "papers", 21600));
        list.add(Map.of("region", "Middle East", "lat", 28.0, "lng", 45.0, "density", 41, "papers", 16800));
        return list;
    }

    private List<Map<String, Object>> defaultKeywords() {
        List<Map<String, Object>> list = new ArrayList<>();
        list.add(Map.of("keyword", "Deep Learning", "count", 14200, "growth", 58.2));
        list.add(Map.of("keyword", "Neural Networks", "count", 12800, "growth", 12.4));
        list.add(Map.of("keyword", "Encryption", "count", 8900, "growth", 34.7));
        list.add(Map.of("keyword", "Reinforcement Learning", "count", 7600, "growth", 41.3));
        list.add(Map.of("keyword", "Natural Language Processing", "count", 6200, "growth", 29.8));
        list.add(Map.of("keyword", "Convolutional Neural Network", "count", 5800, "growth", 22.1));
        list.add(Map.of("keyword", "Cloud Computing", "count", 4100, "growth", 17.5));
        list.add(Map.of("keyword", "Recurrent Neural Network", "count", 3900, "growth", 13.6));
        list.add(Map.of("keyword", "Object Detection", "count", 9200, "growth", 31.4));
        list.add(Map.of("keyword", "Random Forest", "count", 5500, "growth", 18.2));
        return list;
    }

    private List<Map<String, Object>> defaultInsights() {
        List<Map<String, Object>> list = new ArrayList<>();
        list.add(makeInsight("AI Dominance Continues", "Artificial Intelligence publications grew 32.5% YoY, outpacing all other technology domains globally.", "🤖", "up"));
        list.add(makeInsight("Machine Learning Surge", "Machine learning research doubled since 2022, driven by advances in deep learning and LLMs.", "⚛️", "up"));
        list.add(makeInsight("Security Focus Growing", "With rising cyber threats, cybersecurity papers up 21.9%. Zero-trust architecture gaining traction.", "🛡️", "up"));
        list.add(makeInsight("Research Output Expanding", "Global technology research output continues to accelerate across all major domains.", "🌍", "stable"));
        return list;
    }

    private record CacheEntry(Object data, long timestamp) {}
}
