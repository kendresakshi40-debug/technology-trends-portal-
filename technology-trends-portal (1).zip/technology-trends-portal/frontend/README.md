# 🌐 Global Real-Time Trend Intelligence Portal

A web app that tracks **technology trends around the world** — think of it as a dashboard that shows you what's hot in tech, where the research is happening, and what keywords everyone is talking about.

---

## 📌 What Does This Project Do?

Imagine you want to know:
- "Is AI still growing?" → Yes, +32.5% this year!
- "Which countries publish the most research?" → East Asia, North America, Europe
- "What are the top keywords researchers are using?" → Generative AI, LLMs, Zero Trust...

This portal gives you all of that in one beautiful dashboard.

---

## 🧩 Project Structure (Simple Breakdown)

```
technology-trends-portal/
│
├── backend/          ← The "brain" (Java Spring Boot server)
│   ├── controller/   ← Handles requests (login, get data, etc.)
│   ├── model/        ← Defines what a "User" looks like in the database
│   ├── security/     ← JWT tokens & password protection
│   ├── service/      ← Business logic (login checks, registration)
│   └── config/       ← Security rules, CORS, default admin setup
│
└── frontend/         ← The "face" (what you see in the browser)
    ├── index.html          ← Login page (User + Admin tabs)
    ├── admin-login.html    ← Separate admin login page
    ├── register.html       ← Create a new account
    ├── forgot-password.html← Reset your password
    ├── dashboard.html      ← Main dashboard (after login)
    ├── admin-dashboard.html← Admin panel
    ├── css/                ← All the styling (colors, layout)
    └── js/                 ← JavaScript (API calls, login logic)
```

---

## 🔐 Login System

There are **two types of users**:

| Type | What they can do |
|------|-----------------|
| **User** | View dashboard, see trends, browse research data |
| **Admin** | Everything a user can + manage users, view system stats |

### Login Features:
- ✅ **Email & Password** login
- ✅ **Remember Me** — stay logged in for 7 days
- ✅ **Forgot Password** — sends a reset link (placeholder for now)
- ✅ **Create Account** — register with name, email, password
- ✅ **Sign in with Google** — uses Google OAuth2
- ✅ **Sign in with Facebook** — (coming soon)
- ✅ **Admin Login** — separate tab or page, only admins can access

### Default Admin Account:
```
Email:    admin@trends.com
Password: admin123
```

---

## 📊 Dashboard Features

Once you log in, you see:

### 1. 🗺️ World Map — Technology Trend Density
A map showing **where in the world** tech research is happening. Bigger, brighter dots = more papers published. Hover over dots to see numbers.

### 2. 🚀 Top Trending Technologies
Cards showing the **8 hottest technologies** right now — AI, Quantum Computing, Blockchain, etc. Each shows growth % and number of publications.

### 3. 📈 Publication Trends Chart
A line chart showing how research publications have grown over the last **8 years** for AI, Quantum, Blockchain, and Cybersecurity.

### 4. 💡 Key Insights
AI-style analysis cards that summarize what's happening:
- "AI dominance continues with 32.5% growth"
- "Quantum computing research doubled since 2022"
- etc.

### 5. 🔬 Top Research Keywords
A cloud of the most-used keywords in recent research papers — like "Large Language Models", "Generative AI", "Zero Trust Security" — with how fast each is growing.

---

## �️ Admin Dashboard

A separate **control panel** for administrators. Access it via the Admin Login page (`admin-login.html`).

### Overview Page
- **Stat Cards** — Total users, admins, active users, new signups this week
- **User Growth Chart** — Line chart showing signups over the last 6 months
- **Role Distribution** — Doughnut chart showing admin vs regular user split
- **Recent Users** — Table of the 5 most recently joined users

### Users Management Page
- **Full user table** with name, email, role, status, and join date
- **Search** by name or email
- **Filter** by role (Admin/User) or status (Active/Disabled)
- **Actions for each user:**
  - 🔄 **Toggle** — Enable or disable a user's account
  - 🛡️ **Change Role** — Switch between Admin and User
  - 🗑️ **Delete** — Permanently remove a user (with confirmation popup)

### Safety Rules
- Cannot delete the last remaining admin
- Cannot demote the last remaining admin to a regular user
- Delete always asks for confirmation first

### Default Accounts
| Account | Email | Password | Role |
|---------|-------|----------|------|
| System Admin | admin@trends.com | admin123 | Admin |
| Rahul Sharma | rahul@example.com | user123 | User |
| Priya Patel | priya@example.com | user123 | User |
| Amit Kumar | amit@example.com | user123 | User |

> For a detailed walkthrough of the admin dashboard, see [ADMIN-DASHBOARD.md](ADMIN-DASHBOARD.md)

---

## �🛠️ How to Run This Project

### Prerequisites
- **Java 17** — [Download here](https://adoptium.net/temurin/releases/)
- **Maven** — [Download here](https://maven.apache.org/download.cgi)
- **MySQL 8** — [Download here](https://dev.mysql.com/downloads/installer/)

### Step 1: Create the Database
Open MySQL and run:
```sql
CREATE DATABASE trends_db;
```

### Step 2: Start the Backend
```bash
cd backend
mvn spring-boot:run
```
The server starts on **http://localhost:8080**

### Step 3: Open the Frontend
Just open `frontend/index.html` in your browser.
Or use VS Code **Live Server** extension (right-click → Open with Live Server).

---

## ⚙️ Configuration

All settings are in `backend/src/main/resources/application.properties`:

| Setting | What it does |
|---------|-------------|
| `spring.datasource.url` | Your MySQL database URL |
| `spring.datasource.password` | Your MySQL root password |
| `app.jwt.secret` | Secret key for login tokens |
| `app.jwt.expiration-ms` | How long a login session lasts |
| Google OAuth2 settings | For "Sign in with Google" |

---

## 🧪 Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | HTML, CSS, JavaScript, Chart.js, Leaflet.js |
| Backend | Java 17, Spring Boot 3.2, Spring Security |
| Database | MySQL 8 |
| Auth | JWT tokens + Google OAuth2 |
| Maps | Leaflet.js with CARTO dark tiles |
| Data Source | OpenAlex API (free academic research data) |
| Styling | Custom CSS with glassmorphism design |

---

## 📝 Notes

- Dashboard data comes from the **OpenAlex API** — a free, open database of academic research. The backend fetches live data and caches it for 1 hour.
- The world map uses **Leaflet.js** with CARTO dark tiles to show where research is concentrated globally.
- Facebook login is commented out for now — you can enable it by adding your Facebook App credentials.
- The app uses **JWT tokens** stored in localStorage/sessionStorage — no cookies needed.
- The admin dashboard is fully functional with user management (toggle, role change, delete) and built-in safety guards.

---

Made with ☕ and code.
