# Admin Dashboard - How It Works

## What is the Admin Dashboard?

The Admin Dashboard is a **private control panel** that only administrators can access. It lets the admin manage all the users who have signed up on the Technology Trends Portal.

Think of it like the "manager's office" of the website — regular users can't get in, only admins.

---

## How to Access It

1. Go to the **Admin Login** page (`admin-login.html`)
2. Enter the admin email and password:
   - **Email:** admin@trends.com
   - **Password:** admin123
3. If the login is successful, you are redirected to the Admin Dashboard

> Only accounts with the **Admin** role can log in here. Regular users will be rejected.

---

## What's Inside the Dashboard

The dashboard has **two pages** you can switch between using the sidebar on the left:

### 1. Overview Page

This is the **home page** of the dashboard. It shows a quick summary of everything:

- **Total Users** — How many people have signed up
- **Admin Users** — How many of those are admins
- **Active Users** — How many accounts are currently enabled (not disabled)
- **New This Week** — How many users signed up in the last 7 days

It also has:

- **User Growth Chart** (line chart) — Shows how many users joined each month over the last 6 months
- **Role Distribution Chart** (doughnut chart) — A pie-like chart showing how many admins vs regular users exist
- **Recent Users Table** — A small table showing the 5 most recently registered users

### 2. Users Page

This is where you **manage individual users**. It shows a full table of every user with:

- Their **name**, **email**, **role** (Admin or User), **status** (Active or Disabled), and **join date**
- **Action buttons** for each user (explained below)

You can also:

- **Search** users by name or email using the search bar
- **Filter** users by role (All, Admin, User) or status (All, Active, Disabled)

---

## What Can the Admin Do?

### Enable / Disable a User
- Click the **toggle button** (power icon) next to a user
- If they're active, this **disables** them (they can't log in anymore)
- If they're disabled, this **enables** them (they can log in again)
- This does NOT delete the user — it just blocks/unblocks their access

### Change a User's Role
- Click the **role button** (shield icon) next to a user
- If they're a regular **User**, they become an **Admin**
- If they're an **Admin**, they become a regular **User**
- You **cannot** demote yourself if you're the last remaining admin (the system protects against this)

### Delete a User
- Click the **delete button** (trash icon) next to a user
- A confirmation popup will appear asking "Are you sure?"
- If you confirm, the user is **permanently removed** from the system
- You **cannot** delete the last remaining admin account

---

## Safety Rules

The system has built-in protections so the admin doesn't accidentally break things:

1. **Can't delete the last admin** — There must always be at least one admin account
2. **Can't demote the last admin** — If there's only one admin, you can't change their role to User
3. **Confirmation before delete** — A popup always asks you to confirm before deleting someone

---

## Behind the Scenes (Simple Version)

Here's what happens when you use the dashboard:

1. You **log in** → The backend checks your email/password and makes sure you're an admin. It sends back a **token** (like a temporary pass).
2. The dashboard **loads data** → It uses that token to ask the backend for user stats and the list of users.
3. You **click a button** → The frontend sends a request to the backend (e.g., "disable user #3"). The backend makes the change in the database and sends back the result.
4. The dashboard **refreshes** → After every action, the page automatically reloads the latest data so you always see the current state.

All communication between the frontend and backend uses the **REST API** over HTTP. The admin token is sent with every request to prove you're authorized.

---

## Files Involved

| File | What It Does |
|------|-------------|
| `admin-login.html` | The login page for admins |
| `admin-dashboard.html` | The dashboard page layout (HTML structure) |
| `css/admin.css` | The styling — dark theme, cards, tables, sidebar |
| `js/admin.js` | The brains — loads data, handles button clicks, talks to the backend |
| `js/auth.js` | Shared login/token helper functions |
| Backend: `AdminController.java` | Handles all admin API requests (get stats, list users, toggle, delete, etc.) |
| Backend: `SecurityConfig.java` | Makes sure only admin accounts can access `/api/admin/**` endpoints |
| Backend: `DataInitializer.java` | Creates the default admin account and dummy users when the app starts |
