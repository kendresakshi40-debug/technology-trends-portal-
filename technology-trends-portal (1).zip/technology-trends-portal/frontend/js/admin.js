// ==========================================
//  Admin Dashboard – JavaScript
// ==========================================

const ADMIN_API = 'http://localhost:8080/api/admin';

// ── Auth Guard ──
auth.requireAdmin();
const currentUser = auth.getUser();
if (currentUser) {
    document.getElementById('adminName').textContent = currentUser.fullName;
    const initials = currentUser.fullName.split(' ').map(n => n[0]).join('').toUpperCase();
    document.getElementById('adminAvatar').textContent = initials;
}

// ── State ──
let allUsers = [];
let pendingAction = null;
let growthChart = null;
let roleChart = null;
let memoryChart = null;

// ── API Helpers ──
async function adminFetch(url, opts = {}) {
    const token = auth.getToken();
    const res = await fetch(ADMIN_API + url, {
        ...opts,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token,
            ...(opts.headers || {})
        }
    });
    if (!res.ok) {
        const body = await res.text();
        let msg = res.statusText;
        try { msg = JSON.parse(body).message || msg; } catch(_) { msg = body || msg; }
        throw new Error(msg);
    }
    return res.json();
}

// ── Navigation ──
function switchPage(page, el) {
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    document.getElementById('page-' + page).classList.add('active');
    if (el) el.classList.add('active');
    document.getElementById('pageTitle').textContent =
        page === 'overview' ? 'Overview' : 'User Management';
}

function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('open');
}

// ── Clock ──
function updateClock() {
    const now = new Date();
    document.getElementById('topbarTime').textContent = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}
setInterval(updateClock, 1000);
updateClock();

// ── Colours ──
const avatarColors = [
    '#38bdf8','#a78bfa','#fb923c','#34d399','#f87171',
    '#fbbf24','#818cf8','#e879f9','#22d3ee','#4ade80'
];
function colorFor(name) {
    let hash = 0;
    for (let i = 0; i < name.length; i++) hash = name.charCodeAt(i) + ((hash << 5) - hash);
    return avatarColors[Math.abs(hash) % avatarColors.length];
}

// ══════════════════════════════════════════
//  OVERVIEW
// ══════════════════════════════════════════

async function loadOverview() {
    try {
        const [stats, growth, users] = await Promise.all([
            adminFetch('/stats'),
            adminFetch('/user-growth'),
            adminFetch('/users')
        ]);
        allUsers = users;

        // Stats cards
        document.getElementById('statTotal').textContent = stats.totalUsers;
        document.getElementById('statAdmins').textContent = stats.admins;
        document.getElementById('statEnabled').textContent = stats.enabledUsers;
        document.getElementById('statDisabled').textContent = stats.disabledUsers;
        document.getElementById('statNewWeek').textContent = '+' + stats.newThisWeek + ' this week';

        // Growth chart
        renderGrowthChart(growth);

        // Role doughnut
        renderRoleChart(stats);

        // Recent users (last 5)
        const sorted = [...users].sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));
        renderRecentUsers(sorted.slice(0, 5));

        // User count badge
        document.getElementById('userCount').textContent = users.length;

        // Also render full users table
        renderAllUsers(users);
    } catch (err) {
        console.error('Failed to load overview:', err);
    }
}

function renderGrowthChart(growth) {
    const ctx = document.getElementById('growthChart').getContext('2d');
    if (growthChart) growthChart.destroy();
    growthChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: growth.labels,
            datasets: [{
                label: 'Total Users',
                data: growth.data,
                borderColor: '#38bdf8',
                backgroundColor: 'rgba(56,189,248,0.08)',
                fill: true,
                tension: 0.4,
                pointRadius: 0,
                pointHoverRadius: 5,
                pointHoverBackgroundColor: '#38bdf8',
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: 'rgba(15,15,30,0.95)',
                    borderColor: 'rgba(56,189,248,0.3)',
                    borderWidth: 1,
                    titleColor: '#38bdf8',
                    bodyColor: '#fff',
                    cornerRadius: 8,
                    padding: 10
                }
            },
            scales: {
                x: {
                    grid: { color: 'rgba(255,255,255,0.04)' },
                    ticks: { color: 'rgba(255,255,255,0.3)', font: { size: 10 }, maxTicksLimit: 10 }
                },
                y: {
                    grid: { color: 'rgba(255,255,255,0.04)' },
                    ticks: { color: 'rgba(255,255,255,0.3)', font: { size: 10 } },
                    beginAtZero: true
                }
            }
        }
    });
}

function renderRoleChart(stats) {
    const ctx = document.getElementById('roleChart').getContext('2d');
    if (roleChart) roleChart.destroy();
    roleChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Admins', 'Users', 'Disabled'],
            datasets: [{
                data: [stats.admins, Math.max(0, stats.enabledUsers - stats.admins), stats.disabledUsers],
                backgroundColor: ['#a78bfa', '#38bdf8', '#f87171'],
                borderColor: 'transparent',
                borderWidth: 0,
                hoverOffset: 6
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: '70%',
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: { color: 'rgba(255,255,255,0.6)', font: { size: 12 }, padding: 14, usePointStyle: true, pointStyleWidth: 8 }
                }
            }
        }
    });
}

function renderRecentUsers(users) {
    const tbody = document.getElementById('recentUsersBody');
    tbody.innerHTML = users.map(u => {
        const initials = u.fullName.split(' ').map(n => n[0]).join('').toUpperCase();
        const roleBadge = u.role === 'ROLE_ADMIN' ? '<span class="badge badge-admin">Admin</span>' : '<span class="badge badge-user">User</span>';
        const statusBadge = u.enabled ? '<span class="badge badge-active">Active</span>' : '<span class="badge badge-disabled">Disabled</span>';
        const date = u.createdAt ? new Date(u.createdAt).toLocaleDateString() : '--';
        return `<tr>
            <td><div class="user-cell"><div class="user-avatar-sm" style="background:${colorFor(u.fullName)}">${initials}</div><span class="user-name-text">${escapeHtml(u.fullName)}</span></div></td>
            <td>${escapeHtml(u.email)}</td>
            <td>${roleBadge}</td>
            <td>${statusBadge}</td>
            <td>${date}</td>
        </tr>`;
    }).join('');
}

// ══════════════════════════════════════════
//  USERS PAGE
// ══════════════════════════════════════════

function renderAllUsers(users) {
    const tbody = document.getElementById('allUsersBody');
    tbody.innerHTML = users.map(u => {
        const initials = u.fullName.split(' ').map(n => n[0]).join('').toUpperCase();
        const roleBadge = u.role === 'ROLE_ADMIN' ? '<span class="badge badge-admin">Admin</span>' : '<span class="badge badge-user">User</span>';
        const statusBadge = u.enabled ? '<span class="badge badge-active">Active</span>' : '<span class="badge badge-disabled">Disabled</span>';
        const provBadge = u.provider === 'GOOGLE' ? '<span class="badge badge-google">Google</span>' : '<span class="badge badge-local">Local</span>';
        const date = u.createdAt ? new Date(u.createdAt).toLocaleDateString() : '--';
        const toggleLabel = u.enabled ? 'Disable' : 'Enable';
        const newRole = u.role === 'ROLE_ADMIN' ? 'ROLE_USER' : 'ROLE_ADMIN';
        const roleLabel = u.role === 'ROLE_ADMIN' ? '→ User' : '→ Admin';
        const safeName = escapeHtml(u.fullName).replace(/'/g, '&#39;').replace(/"/g, '&quot;');
        return `<tr>
            <td><div class="user-cell"><div class="user-avatar-sm" style="background:${colorFor(u.fullName)}">${initials}</div><span class="user-name-text">${escapeHtml(u.fullName)}</span></div></td>
            <td>${escapeHtml(u.email)}</td>
            <td>${provBadge}</td>
            <td>${roleBadge}</td>
            <td>${statusBadge}</td>
            <td>${date}</td>
            <td>
                <div class="action-group">
                    <button class="btn-action btn-toggle" data-id="${u.id}" data-action="toggle">${toggleLabel}</button>
                    <button class="btn-action btn-role" data-id="${u.id}" data-role="${newRole}" data-action="role">${roleLabel}</button>
                    <button class="btn-action btn-delete" data-id="${u.id}" data-name="${safeName}" data-action="delete">Delete</button>
                </div>
            </td>
        </tr>`;
    }).join('');
    document.getElementById('userCount').textContent = users.length;

    // Attach event listeners via delegation
    tbody.onclick = function(e) {
        const btn = e.target.closest('[data-action]');
        if (!btn) return;
        const id = Number(btn.dataset.id);
        if (btn.dataset.action === 'toggle') toggleUser(id);
        else if (btn.dataset.action === 'role') changeRole(id, btn.dataset.role);
        else if (btn.dataset.action === 'delete') confirmDelete(id, btn.dataset.name);
    };
}

function filterUsers() {
    const search = document.getElementById('userSearch').value.toLowerCase();
    const roleF = document.getElementById('roleFilter').value;
    const statusF = document.getElementById('statusFilter').value;

    const filtered = allUsers.filter(u => {
        const matchSearch = u.fullName.toLowerCase().includes(search) || u.email.toLowerCase().includes(search);
        const matchRole = !roleF || u.role === roleF;
        const matchStatus = statusF === '' || String(u.enabled) === statusF;
        return matchSearch && matchRole && matchStatus;
    });
    renderAllUsers(filtered);
}

async function toggleUser(id) {
    try {
        await adminFetch(`/users/${id}/toggle`, { method: 'PUT' });
    } catch (e) {
        alert(e.message);
    }
    await loadOverview();
}

async function changeRole(id, newRole) {
    try {
        await adminFetch(`/users/${id}/role`, {
            method: 'PUT',
            body: JSON.stringify({ role: newRole })
        });
    } catch (e) {
        alert(e.message);
    }
    await loadOverview();
}

function confirmDelete(id, name) {
    pendingAction = () => deleteUser(id);
    document.getElementById('modalTitle').textContent = 'Delete User';
    document.getElementById('modalMessage').textContent = `Are you sure you want to delete "${name}"? This cannot be undone.`;
    document.getElementById('modalOverlay').classList.add('open');
}

async function deleteUser(id) {
    try {
        await adminFetch(`/users/${id}`, { method: 'DELETE' });
    } catch (e) {
        alert(e.message);
    }
    await loadOverview();
}

function confirmAction() {
    closeModal();
    if (pendingAction) { pendingAction(); pendingAction = null; }
}
function closeModal() {
    document.getElementById('modalOverlay').classList.remove('open');
}

// ── Utility ──
function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
}

// ── Init ──
loadOverview();
