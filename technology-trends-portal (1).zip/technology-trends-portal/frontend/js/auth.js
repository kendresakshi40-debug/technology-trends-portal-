// ==========================================
// API Configuration & Auth Utilities
// ==========================================

const API_BASE = 'http://localhost:8080/api';

const api = {
    async post(endpoint, data) {
        const response = await fetch(`${API_BASE}${endpoint}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        const text = await response.text();
        const result = text ? JSON.parse(text) : {};
        if (!response.ok) {
            throw new Error(result.message || result.error || 'Invalid email or password');
        }
        return result;
    },

    async get(endpoint) {
        const token = auth.getToken();
        const response = await fetch(`${API_BASE}${endpoint}`, {
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            }
        });
        if (response.status === 401) {
            auth.logout();
            return;
        }
        const result = await response.json();
        if (!response.ok) {
            throw new Error(result.message || 'Something went wrong');
        }
        return result;
    }
};

const auth = {
    saveSession(data, rememberMe) {
        const storage = rememberMe ? localStorage : sessionStorage;
        storage.setItem('token', data.token);
        storage.setItem('role', data.role);
        storage.setItem('fullName', data.fullName);
        storage.setItem('email', data.email);
    },

    getToken() {
        return localStorage.getItem('token') || sessionStorage.getItem('token');
    },

    getUser() {
        const storage = localStorage.getItem('token') ? localStorage : sessionStorage;
        return {
            token: storage.getItem('token'),
            role: storage.getItem('role'),
            fullName: storage.getItem('fullName'),
            email: storage.getItem('email')
        };
    },

    isLoggedIn() {
        return !!this.getToken();
    },

    isAdmin() {
        const user = this.getUser();
        return user.role === 'ROLE_ADMIN';
    },

    logout() {
        localStorage.clear();
        sessionStorage.clear();
        window.location.href = 'index.html';
    },

    requireAuth() {
        if (!this.isLoggedIn()) {
            window.location.href = 'index.html';
        }
    },

    requireAdmin() {
        if (!this.isLoggedIn() || !this.isAdmin()) {
            window.location.href = 'admin-login.html';
        }
    }
};

// UI Helpers
function showAlert(id, message, type = 'error') {
    const el = document.getElementById(id);
    if (!el) return;
    el.className = `alert alert-${type} show`;
    el.textContent = message;
    if (type === 'success') {
        setTimeout(() => el.classList.remove('show'), 4000);
    }
}

function hideAlert(id) {
    const el = document.getElementById(id);
    if (el) el.classList.remove('show');
}

function setLoading(btn, loading) {
    if (loading) {
        btn.classList.add('loading');
        btn.disabled = true;
    } else {
        btn.classList.remove('loading');
        btn.disabled = false;
    }
}

function togglePassword(inputId) {
    const input = document.getElementById(inputId);
    const icon = input.parentElement.querySelector('.toggle-password');
    if (input.type === 'password') {
        input.type = 'text';
        icon.textContent = '🙈';
    } else {
        input.type = 'password';
        icon.textContent = '👁️';
    }
}
